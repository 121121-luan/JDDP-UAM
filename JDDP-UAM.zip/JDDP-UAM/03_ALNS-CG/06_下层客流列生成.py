def paths_equal(p1: PathFlow, p2: PathFlow) -> bool:

    if p1 is p2:
        return True
    if p1 is None or p2 is None:
        return False
    if p1.origin != p2.origin or p1.destination != p2.destination:
        return False
    if p1.node_sequence is None or p2.node_sequence is None:
        return False
    if p1.mode_sequence is None or p2.mode_sequence is None:
        return False
    if len(p1.node_sequence) != len(p2.node_sequence):
        return False
    if len(p1.mode_sequence) != len(p2.mode_sequence):
        return False
    for i in range(len(p1.node_sequence)):
        if p1.node_sequence[i] != p2.node_sequence[i]:
            return False
    for i in range(len(p1.mode_sequence)):
        if p1.mode_sequence[i] != p2.mode_sequence[i]:
            return False
    return True

def build_auxiliary_network(upper: UpperSolution, data: ProblemData,
                            dual_u2: np.ndarray, time: int) -> np.ndarray:

    n = data.node_count
    net = np.full((n, n, 2), INF)
    for k in range(n):
        for m in range(n):
            if k == m:
                continue

            if data.ground_link_exists[k, m]:
                net[k, m, 1] = (data.ground_travel_fare[k, m]
                                + data.value_of_time * data.ground_travel_time[k, m, time])

            if data.uam_link_exists[k, m] and upper.q[k, m, time] > 0:
                dual = dual_u2[k, m] if dual_u2 is not None else 0.0
                net[k, m, 0] = (upper.p[k, m, time]
                                + data.value_of_time * data.uam_travel_time[k, m]
                                + dual)
    return net

def spfa(net: np.ndarray, source: int, dest: int) -> Optional[Tuple[float, List[int], List[int]]]:

    n = net.shape[0]
    dist = np.full(n, INF)
    prev_node = np.full(n, -1, dtype=int)
    prev_mode = np.full(n, -1, dtype=int)
    in_queue = np.zeros(n, dtype=bool)
    count = np.zeros(n, dtype=int)

    dist[source] = 0.0
    queue = [source]
    in_queue[source] = True
    count[source] = 1

    while queue:
        u = queue.pop(0)
        in_queue[u] = False
        for v in range(n):
            if u == v:
                continue
            for mode in (0, 1):
                w = net[u, v, mode]
                if w < INF:
                    if dist[v] > dist[u] + w:
                        dist[v] = dist[u] + w
                        prev_node[v] = u
                        prev_mode[v] = mode
                        if not in_queue[v]:
                            queue.append(v)
                            in_queue[v] = True
                            count[v] += 1
                            if count[v] > n:
                                print("检测到负环")
                                return None

    if dist[dest] >= INF:
        return None

    nodes = []
    modes = []
    cur = dest
    while cur != source:
        prev = prev_node[cur]
        if prev == -1:
            return None
        nodes.insert(0, cur)
        modes.insert(0, prev_mode[cur])
        cur = prev
    nodes.insert(0, source)
    return dist[dest], nodes, modes

def solve_rmp(od_path_map: Dict, upper: UpperSolution, data: ProblemData,
              time: int) -> Optional[Tuple[np.ndarray, np.ndarray, List[float]]]:

    n = data.node_count
    try:
        cpx = cplex.Cplex()
        cpx.set_log_stream(None)
        cpx.set_error_stream(None)
        cpx.set_warning_stream(None)

        cpx.set_results_stream(None)
        cpx.parameters.read.datacheck.set(0)

        all_paths: List[PathFlow] = []
        var_names = []
        od_keys = list(od_path_map.keys())
        for od in od_keys:
            for p in od_path_map[od]:
                all_paths.append(p)
                var_names.append(f"y_{od[0]}_{od[1]}_{p.path_id}")

        if len(all_paths) == 0:
            cpx.end()
            return None

        obj = [0.0] * len(all_paths)
        for idx, p in enumerate(all_paths):
            cost = p.calculate_generalized_cost(upper, data, time)
            od_demand = data.od_demand[p.origin, p.destination, time]
            obj[idx] = od_demand * cost

        cpx.variables.add(obj=obj, lb=[0.0] * len(all_paths),
                          names=var_names)

        idx = 0
        for od in od_keys:
            paths = od_path_map[od]
            row = [1.0] * len(paths)
            cols = list(range(idx, idx + len(paths)))
            cpx.linear_constraints.add(
                lin_expr=[cplex.SparsePair(ind=cols, val=row)],
                senses=["E"],
                rhs=[1.0],
                names=[f"demand_{od[0]}_{od[1]}"]
            )
            idx += len(paths)

        for k in range(n):
            for m in range(n):
                if k == m or not data.uam_link_exists[k, m]:
                    continue
                row_vals = []
                row_cols = []
                for idx2, p in enumerate(all_paths):
                    if p.contains_uam_link(k, m):
                        od_demand = data.od_demand[p.origin, p.destination, time]
                        row_vals.append(od_demand)
                        row_cols.append(idx2)
                cap = data.passenger_capacity * upper.q[k, m, time]
                cpx.linear_constraints.add(
                    lin_expr=[cplex.SparsePair(ind=row_cols, val=row_vals)],
                    senses=["L"],
                    rhs=[cap],
                    names=[f"cap_{k}_{m}_{time}"]
                )

        cpx.solve()
        status = cpx.solution.get_status()
        if status != 1:
            cpx.end()
            return None

        dual_u1 = np.zeros((n, n))
        for od in od_keys:
            try:
                dual_u1[od[0], od[1]] = cpx.solution.get_dual_values(f"demand_{od[0]}_{od[1]}")
            except CplexError:
                dual_u1[od[0], od[1]] = 0.0

        dual_u2 = np.zeros((n, n))
        for k in range(n):
            for m in range(n):
                if k == m or not data.uam_link_exists[k, m]:
                    continue
                try:
                    dual_u2[k, m] = - cpx.solution.get_dual_values(f"cap_{k}_{m}_{time}")
                except CplexError:
                    pass

        y_vals = cpx.solution.get_values()
        cpx.end()

        del cpx
        gc.collect()
        return dual_u1, dual_u2, y_vals

    except CplexError as e:
        print(f"    CPLEX error in solve_rmp: {e}")
        return None

def solve_one_time_stage(args):

    upper, data, time, verbose = args

    if verbose:
        print(f"[进程 {multiprocessing.current_process().pid}] 开始求解时间阶段 {time}")

    n = data.node_count
    t = data.time_stage_count

    od_path_map = defaultdict(list)
    path_counter = 0

    for i in range(n):
        for j in range(n):
            if i == j:
                continue

            if data.uam_link_exists[i, j] and upper.q[i, j, time] > 0:
                p = PathFlow(i, j, path_counter, [i, j], [0], np.zeros(t))
                od_path_map[(i, j)].append(p)
                path_counter += 1

            if data.ground_link_exists[i, j]:
                p = PathFlow(i, j, path_counter, [i, j], [1], np.zeros(t))
                od_path_map[(i, j)].append(p)
                path_counter += 1

    max_iter = 20
    has_negative_reduced_cost = True
    y_vals = []
    solved_paths = []
    dual_u1_result = np.zeros((n, n))
    dual_u2_result = np.zeros((n, n))

    for it in range(max_iter):
        if not has_negative_reduced_cost:
            break

        rmp_paths = [p for paths in od_path_map.values() for p in paths]
        rmp = solve_rmp(od_path_map, upper, data, time)
        if rmp is None:
            if not solved_paths:
                raise RuntimeError(f"时间阶段 {time} 的初始RMP求解失败")
            if verbose:
                print(f"  [时间{time}] RMP求解失败，迭代 {it}")
            break

        dual_u1, dual_u2, y_vals = rmp
        if len(y_vals) != len(rmp_paths):
            raise RuntimeError(f"时间阶段 {time} 的RMP路径数与流量数不一致")
        solved_paths = rmp_paths

        for i in range(n):
            for j in range(n):
                dual_u1_result[i, j] = dual_u1[i, j]
        for k in range(n):
            for m in range(n):
                dual_u2_result[k, m] = dual_u2[k, m]

        aux_net = build_auxiliary_network(upper, data, dual_u2, time)

        has_negative_reduced_cost = False
        new_paths_count = 0

        for i in range(n):
            for j in range(n):
                if i == j:
                    continue

                sp = spfa(aux_net, i, j)
                if sp is None:
                    continue
                shortest_cost, nodes, modes = sp

                od_demand = data.od_demand[i, j, time]
                reduced_cost = od_demand * shortest_cost - dual_u1[i, j]

                if reduced_cost < -1e-6:
                    new_path = PathFlow(i, j, path_counter, nodes, modes, np.zeros(t))
                    path_counter += 1

                    exists = any(paths_equal(p, new_path) for p in od_path_map[(i, j)])
                    if not exists:
                        od_path_map[(i, j)].append(new_path)
                        has_negative_reduced_cost = True
                        new_paths_count += 1

        if verbose:
            print(f"  [时间{time}] 迭代 {it + 1}: 发现 {new_paths_count} 条新路径")

    result_path_flows = []
    od_flow_totals = defaultdict(float)
    air_flow = np.zeros((n, n))
    for p, value in zip(solved_paths, y_vals):
        value = float(value)
        if not np.isfinite(value) or value < -1e-6:
            raise RuntimeError(f"时间阶段 {time} 的RMP返回非法路径流量: {value}")
        p.flow = np.zeros(t)
        p.flow[time] = max(0.0, value)
        result_path_flows.append(p)
        od_flow_totals[(p.origin, p.destination)] += p.flow[time]
        passengers = data.od_demand[p.origin, p.destination, time] * p.flow[time]
        for k, m, mode in zip(p.node_sequence, p.node_sequence[1:], p.mode_sequence):
            if mode == 0:
                air_flow[k, m] += passengers

    if any(abs(total - 1.0) > 1e-6 for total in od_flow_totals.values()):
        raise RuntimeError(f"时间阶段 {time} 的OD路径流量比例之和不为1")
    if np.any(air_flow - data.passenger_capacity * upper.q[:, :, time] > 1e-5):
        raise RuntimeError(f"时间阶段 {time} 的UAM客流超过座位容量")

    total_cost = 0.0
    for p in result_path_flows:
        if p.flow[time] > 0:
            od_demand = data.od_demand[p.origin, p.destination, time]
            cost = p.calculate_generalized_cost(upper, data, time)
            total_cost += od_demand * p.flow[time] * cost

    if verbose:
        print(f"[进程 {multiprocessing.current_process().pid}] 时间阶段 {time} 求解完成")

    return (time, result_path_flows, dual_u1_result, dual_u2_result, total_cost)

def solve_lower_level_parallel(upper: UpperSolution, data: ProblemData,
                               verbose: bool = False) -> LowerSolution:

    n, t = data.node_count, data.time_stage_count

    task_args = [(upper, data, time, verbose) for time in range(t)]

    max_workers = t

    print(f"\n启动并行求解（{t}个时间阶段，{max_workers}个工作进程）...")

    sol = LowerSolution()
    sol.dual_u1 = np.zeros((n, n, t))
    sol.dual_u2 = np.zeros((n, n, t))
    sol.path_flows = []
    sol.total_generalized_cost = 0.0

    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(solve_one_time_stage, args): args[2]
                   for args in task_args}

        for future in as_completed(futures):
            time = futures[future]
            result = future.result()
            time_idx, path_flows, dual_u1, dual_u2, stage_cost = result

            sol.path_flows.extend(path_flows)
            sol.dual_u1[:, :, time_idx] = dual_u1
            sol.dual_u2[:, :, time_idx] = dual_u2
            sol.total_generalized_cost += stage_cost

            print(f"时间阶段 {time_idx} 并行求解完成，广义成本: {stage_cost:.2f}")

    for idx, p in enumerate(sol.path_flows):
        p.path_id = idx

    print(f"\n并行求解完成，总广义成本: {sol.total_generalized_cost:.2f}")

    return sol
