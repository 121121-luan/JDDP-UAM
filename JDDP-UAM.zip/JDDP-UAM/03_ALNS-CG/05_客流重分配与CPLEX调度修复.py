def compute_current_passenger_flow(sol: UpperSolution, lower: LowerSolution,
                                   data: ProblemData) -> np.ndarray:

    n, t = data.node_count, data.time_stage_count
    passenger_flow = np.zeros((n, n, t))

    if lower is None or not lower.path_flows:
        return passenger_flow

    for p in lower.path_flows:
        origin = p.origin
        dest = p.destination
        for time in range(t):
            flow_ratio = p.flow[time]
            if flow_ratio <= 0:
                continue
            od_demand = data.od_demand[origin, dest, time]
            passengers = od_demand * flow_ratio

            if p.node_sequence is not None and p.mode_sequence is not None:
                for seg in range(len(p.mode_sequence)):
                    if p.mode_sequence[seg] == 0:
                        frm = p.node_sequence[seg]
                        to = p.node_sequence[seg + 1]
                        passenger_flow[frm, to, time] += passengers

    return passenger_flow

def path_contains_uam_link(path: PathFlow, i: int, j: int, time: int) -> bool:

    if path.node_sequence is None or path.mode_sequence is None:
        return False
    for seg in range(len(path.mode_sequence)):
        if path.mode_sequence[seg] == 0:
            frm = path.node_sequence[seg]
            to = path.node_sequence[seg + 1]
            if frm == i and to == j:
                return True
    return False

def path_uses_node(path: PathFlow, nodes: List[int]) -> bool:

    if path.node_sequence is None or not nodes:
        return False
    for seg in range(len(path.mode_sequence)):
        if path.mode_sequence[seg] == 0:
            frm = path.node_sequence[seg]
            to = path.node_sequence[seg + 1]
            if frm in nodes or to in nodes:
                return True
    return False

def calculate_path_generalized_cost(path: PathFlow, sol: UpperSolution,
                                    data: ProblemData, time: int) -> float:

    if path.node_sequence is None or path.mode_sequence is None:
        return 0.0
    total = 0.0
    seg_count = min(len(path.node_sequence) - 1, len(path.mode_sequence))
    for seg in range(seg_count):
        frm = path.node_sequence[seg]
        to = path.node_sequence[seg + 1]
        mode = path.mode_sequence[seg]
        if mode == 0:
            if data.uam_link_exists[frm, to]:
                total += sol.p[frm, to, time] + data.value_of_time * data.uam_travel_time[frm, to]
        else:
            if data.ground_link_exists[frm, to]:
                total += data.ground_travel_fare[frm, to] + data.value_of_time * data.ground_travel_time[frm, to, time]
    return total

def reallocate_passenger_flow(sol: UpperSolution, lower: LowerSolution, data: ProblemData,
                              current_flow: np.ndarray, strategy: int,
                              affected_nodes: List[int]) -> np.ndarray:

    n, t = data.node_count, data.time_stage_count
    beta_od = 5

    updated_flow = np.copy(current_flow)

    if lower is None or not lower.path_flows:
        return updated_flow

    od_time_path_map: Dict[Tuple, Dict[int, List[PathFlow]]] = defaultdict(dict)
    for p in lower.path_flows:
        od_key = (p.origin, p.destination)
        for time in range(t):
            if time not in od_time_path_map[od_key]:
                od_time_path_map[od_key][time] = []
            od_time_path_map[od_key][time].append(p)

    all_od_keys = list(od_time_path_map.keys())
    if not all_od_keys:
        return updated_flow

    _random.shuffle(all_od_keys)
    num_od = min(beta_od, len(all_od_keys))
    selected_od_keys = all_od_keys[:num_od]

    print(f"重分配流量：策略={strategy}, 影响节点={affected_nodes}, 选择的OD对数={num_od}/{len(all_od_keys)}")

    for od_key in selected_od_keys:
        origin, dest = od_key
        for time in range(t):
            paths = od_time_path_map.get(od_key, {}).get(time, [])
            if len(paths) < 2:
                continue

            path_costs = []
            for p in paths:
                cost = calculate_path_generalized_cost(p, sol, data, time)
                path_costs.append((p, cost))
            path_costs.sort(key=lambda x: x[1])

            source_candidates = [(p, c) for p, c in path_costs if p.flow[time] > 0]
            if strategy == ReallocationStrategy.AFTER_DOWNGRADE:
                preferred_sources = [(p, c) for p, c in source_candidates
                                     if path_uses_node(p, affected_nodes)]
                if preferred_sources:
                    source_candidates = preferred_sources

            if not source_candidates:
                continue

            source_path, source_cost = _random.choice(source_candidates)

            target_path = None
            cheaper = [(p, c) for p, c in path_costs if c < source_cost]
            if strategy == ReallocationStrategy.AFTER_UPGRADE:
                preferred_targets = [(p, c) for p, c in cheaper
                                     if path_uses_node(p, affected_nodes)]
                if preferred_targets:
                    cheaper = preferred_targets
            if cheaper:
                target_path, _ = _random.choice(cheaper)

            if target_path is None:
                continue

            od_demand = data.od_demand[origin, dest, time]
            passengers = od_demand * source_path.flow[time]

            for seg in range(len(source_path.mode_sequence)):
                if source_path.mode_sequence[seg] == 0:
                    frm = source_path.node_sequence[seg]
                    to = source_path.node_sequence[seg + 1]
                    updated_flow[frm, to, time] -= passengers

            for seg in range(len(target_path.mode_sequence)):
                if target_path.mode_sequence[seg] == 0:
                    frm = target_path.node_sequence[seg]
                    to = target_path.node_sequence[seg + 1]
                    updated_flow[frm, to, time] += passengers

            if passengers > 0:
                print(f"  OD对({origin}->{dest}) 时间{time}: 转移{passengers:.2f}乘客 "
                      f"从路径{source_path.path_id} 到路径{target_path.path_id}")

    return updated_flow

def optimize_flights_and_evtols_with_cplex(sol: UpperSolution, data: ProblemData,
                                           passenger_flow: np.ndarray) -> UpperSolution:

    new_sol = sol.copy()
    n, t, h = data.node_count, data.time_stage_count, data.vertiport_level_count

    try:
        cpx = cplex.Cplex()
        cpx.set_log_stream(None)
        cpx.set_error_stream(None)
        cpx.set_warning_stream(None)

        cpx.set_results_stream(None)
        cpx.parameters.read.datacheck.set(0)

        period_hours = [4, 6, 4, 10]

        q_vars = {}
        x_vars = {}
        d_vars = {}

        for i in range(n):
            for time in range(t):
                x_vars[(i, time)] = cpx.variables.add(
                    obj=[0], lb=[0], ub=[50], types=['I'],
                    names=[f"x_{i}_{time}"])[0]
            for j in range(n):
                if i == j:
                    continue
                for time in range(t):
                    q_vars[(i, j, time)] = cpx.variables.add(
                        obj=[0], lb=[0], ub=[500], types=['I'],
                        names=[f"q_{i}_{j}_{time}"])[0]
                    ub_d = passenger_flow[i, j, time]
                    d_vars[(i, j, time)] = cpx.variables.add(
                        obj=[0], lb=[0], ub=[ub_d], types=['C'],
                        names=[f"d_{i}_{j}_{time}"])[0]

        obj_pairs = []
        for i in range(n):
            obj_pairs.append((x_vars[(i, 0)], data.evtol_procurement_cost))
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                op_cost = data.flight_operation_cost[i, j]
                for time in range(t):
                    obj_pairs.append((q_vars[(i, j, time)], op_cost))
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                for time in range(t):
                    obj_pairs.append((d_vars[(i, j, time)], -sol.p[i, j, time]))
        cpx.objective.set_linear(obj_pairs)
        cpx.objective.set_sense(cpx.objective.sense.minimize)

        for i in range(n):
            ind = [x_vars[(i, 0)], x_vars[(i, t - 1)]]
            val = [1.0, -1.0]
            for j in range(n):
                if i == j:
                    continue
                ind.append(q_vars[(j, i, t - 1)])
                val.append(-1.0)
                ind.append(q_vars[(i, j, t - 1)])
                val.append(1.0)
            cpx.linear_constraints.add(
                lin_expr=[cplex.SparsePair(ind=ind, val=val)],
                senses=["E"], rhs=[0.0], names=[f"balance_initial_{i}"]
            )

            for time in range(t - 1):
                ind = [x_vars[(i, time + 1)], x_vars[(i, time)]]
                val = [1.0, -1.0]
                for j in range(n):
                    if i == j:
                        continue
                    ind.append(q_vars[(j, i, time)])
                    val.append(-1.0)
                    ind.append(q_vars[(i, j, time)])
                    val.append(1.0)
                cpx.linear_constraints.add(
                    lin_expr=[cplex.SparsePair(ind=ind, val=val)],
                    senses=["E"], rhs=[0.0], names=[f"balance_{i}_{time + 1}"]
                )

        for i in range(n):
            parking_cap = get_node_parking(sol, data, i)
            for time in range(t):
                cpx.linear_constraints.add(
                    lin_expr=[cplex.SparsePair(ind=[x_vars[(i, time)]], val=[1.0])],
                    senses=["L"], rhs=[float(parking_cap)], names=[f"parking_{i}_{time}"]
                )

        for i in range(n):
            pad_count = get_node_pad_count(sol, data, i)
            for time in range(t):
                ind = []
                val = []
                for j in range(n):
                    if i == j:
                        continue
                    ind.append(q_vars[(i, j, time)])
                    val.append(1.0)
                    ind.append(q_vars[(j, i, time)])
                    val.append(1.0)
                max_thru = data.max_throughput_per_pad[time] * pad_count
                cpx.linear_constraints.add(
                    lin_expr=[cplex.SparsePair(ind=ind, val=val)],
                    senses=["L"], rhs=[max_thru], names=[f"throughput_{i}_{time}"]
                )

        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                for time in range(t):
                    rhs = passenger_flow[i, j, time]
                    cpx.linear_constraints.add(
                        lin_expr=[cplex.SparsePair(ind=[d_vars[(i, j, time)]], val=[1.0])],
                        senses=["L"], rhs=[rhs], names=[f"demand_{i}_{j}_{time}"]
                    )

        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                for time in range(t):
                    cpx.linear_constraints.add(
                        lin_expr=[cplex.SparsePair(
                            ind=[d_vars[(i, j, time)], q_vars[(i, j, time)]],
                            val=[1.0, -data.passenger_capacity])],
                        senses=["L"], rhs=[0.0], names=[f"capacity_{i}_{j}_{time}"]
                    )

        for time in range(t):
            ind = []
            val = []
            for i in range(n):
                for j in range(n):
                    if i == j:
                        continue
                    if data.uam_link_exists[i, j]:
                        ind.append(q_vars[(i, j, time)])
                        val.append(data.uam_travel_time[i, j])

            for i in range(n):
                ind.append(x_vars[(i, time)])
                val.append(-0.5*period_hours[time])

            cpx.linear_constraints.add(
                lin_expr=[cplex.SparsePair(ind=ind, val=val)],
                senses=["L"], rhs=[0.0],
                names=[f"flight_hours_{time}"]
            )

        cpx.parameters.mip.tolerances.mipgap.set(0.01)
        cpx.parameters.timelimit.set(60)
        cpx.solve()

        gap = cpx.solution.MIP.get_mip_relative_gap()
        print(f"当前 MIP Relative Gap: {gap}")

        status = cpx.solution.get_status()

        is_optimal = (status == 1 or status == 101 or status == 102)

        if is_optimal:
            for i in range(n):
                for time in range(t):
                    new_sol.x[i, time] = int(round(cpx.solution.get_values(f"x_{i}_{time}")))
                for j in range(n):
                    if i == j:
                        continue
                    for time in range(t):
                        new_sol.q[i, j, time] = int(round(cpx.solution.get_values(f"q_{i}_{j}_{time}")))
            print(f"CPLEX优化完成，目标值: {cpx.solution.get_objective_value():.2f}")
        else:
            print(f"CPLEX求解失败，状态码: {status}")

        cpx.end()

    except CplexError as e:
        print(f"CPLEX求解错误: {e}")
        return sol

    return new_sol
