def roulette_wheel(weights: List[float]) -> int:

    total = sum(weights)
    if total <= 0:
        return _random.randint(0, len(weights) - 1)
    r = _random.random() * total
    cum = 0.0
    for i, w in enumerate(weights):
        cum += w
        if r <= cum:
            return i
    return len(weights) - 1

def accept_solution(new_profit: float, current_profit: float, temperature: float) -> bool:

    if new_profit > current_profit:
        return True
    else:
        prob = np.exp((new_profit - current_profit) / temperature)
        return _random.random() < prob

def optimize_uam_network(data: ProblemData, max_iter: int,
                         initial_upper: Optional[UpperSolution] = None,
                         seed: int = 42, output_dir: Optional[str] = None):

    print("\n===== ALNS-CG Algorithm for JDDP =====")
    print(repeat_string("=", 60))

    random.seed(seed)
    np.random.seed(seed)
    global _random
    _random = random.Random(seed)

    temperature = 1000
    cooling_rate = 0.8
    operator_weights = [100.0] * NUM_OPERATORS
    operator_scores = [0.0] * NUM_OPERATORS
    operator_num = [0] * NUM_OPERATORS
    theta = 0.6
    beta1 = 300.0
    beta2 = 150.0
    beta3 = 50.0
    beta_rejected = 10.0

    select_count = [0] * NUM_OPERATORS
    best_count = [0] * NUM_OPERATORS
    better_count = [0] * NUM_OPERATORS
    accepted_count = [0] * NUM_OPERATORS

    log_iterations = []
    log_current_profit = []
    log_best_profit = []
    log_op_weights = []
    log_wall_time = []

    start_time = time.time()

    print("生成初始解...")
    current_upper = initial_upper.copy() if initial_upper is not None else generate_initial_upper(data)
    print("求解初始下层问题...")
    current_lower = solve_lower_level_parallel(current_upper, data)
    evaluate_upper_solution(current_upper, data, current_lower)
    print(f"初始利润: {current_upper.profit:.2f}")

    best_upper = current_upper.copy()
    best_lower = current_lower.copy()
    print(repeat_string("=", 60))

    stagnation_window = 50
    stagnation_threshold = 0.05
    best_at_window_start = current_upper.profit

    log_iterations.append(0)
    log_current_profit.append(current_upper.profit)
    log_best_profit.append(best_upper.profit)
    log_op_weights.append(list(operator_weights))
    log_wall_time.append(0.0)

    for it in range(max_iter):

        if(log_wall_time[it] >= 14400):
            print(f"迭代 {it:3d}: 提前终止")
            break

        op_idx = roulette_wheel(operator_weights)
        operator_num[op_idx] += 1

        select_count[op_idx] += 1

        new_upper, new_lower = apply_operator(op_idx, current_upper, current_lower, data)

        evaluate_upper_solution(new_upper, data, new_lower)

        if accept_solution(new_upper.profit, current_upper.profit, temperature):

            accepted_count[op_idx] += 1

            if new_upper.profit > best_upper.profit:
                best_count[op_idx] += 1
                operator_scores[op_idx] += beta1
                last_improvement_iter = it
            elif new_upper.profit > current_upper.profit:
                better_count[op_idx] += 1
                operator_scores[op_idx] += beta2
            else:
                operator_scores[op_idx] += beta3

            current_upper = new_upper
            current_lower = new_lower

            if new_upper.profit > best_upper.profit:
                best_upper = new_upper.copy()
                best_lower = new_lower.copy()
                print(f"迭代 {it:3d}: 新最优利润 = {new_upper.profit:10.2f}")
        else:
            operator_scores[op_idx] += beta_rejected

        temperature *= cooling_rate

        if (it + 1) % 20 == 0:
            for i in range(NUM_OPERATORS):
                if operator_num[i] > 0:
                    avg_score = operator_scores[i] / operator_num[i]
                    operator_weights[i] = theta * operator_weights[i] + (1 - theta) * avg_score
                operator_scores[i] = 0.0
                operator_num[i] = 0

            print(f"迭代 {it:3d}: 当前利润 = {current_upper.profit:10.2f}, "
                  f"温度 = {temperature:8.2f}")

        elapsed = time.time() - start_time
        log_iterations.append(it + 1)
        log_current_profit.append(current_upper.profit)
        log_best_profit.append(best_upper.profit)
        log_op_weights.append(list(operator_weights))
        log_wall_time.append(elapsed)

    print(repeat_string("=", 60))
    print("优化完成！")
    print_solution_summary(best_upper, best_lower, data)

    op_names = [
        "1. increase_price",
        "2. decrease_price",
        "3. reoptimize_flights",
        "4. upgrade_vertiport",
        "5. downgrade_vertiport",
    ]
    print("\n" + repeat_string("=", 60))
    print("算子统计表：")
    print(repeat_string("=", 60))
    header = f"  {'算子':<25s} {'选中':>6s} {'→最优':>8s} {'→更好':>8s} {'被接受':>8s} {'接受率':>8s}"
    print(header)
    print("  " + "-" * 58)
    for k in range(NUM_OPERATORS):
        sel = select_count[k]
        bst = best_count[k]
        btr = better_count[k]
        acc = accepted_count[k]
        rate = (acc / sel * 100) if sel > 0 else 0.0
        print(f"  {op_names[k]:<25s} {sel:6d} {bst:8d} {btr:8d} {acc:8d} {rate:7.1f}%")
    print(repeat_string("=", 60))

    log_data = {
        "iterations": log_iterations,
        "current_profit": log_current_profit,
        "best_profit": log_best_profit,
        "op_weights_log": log_op_weights,
        "wall_time": log_wall_time,
        "operator_selected": select_count,
        "operator_accepted": accepted_count,
        "seed": seed,
    }

    if output_dir is None:
        plot_alns_progress_by_iteration(log_data)
        plot_alns_progress_by_time(log_data)
    else:
        import json
        os.makedirs(output_dir, exist_ok=True)
        with open(os.path.join(output_dir, "search_history.json"), "w", encoding="utf-8") as f:
            json.dump(log_data, f, ensure_ascii=False, indent=2)
        plot_alns_progress_by_iteration(log_data, os.path.join(output_dir, "alns_progress_by_iter.png"))
        plot_alns_progress_by_time(log_data, os.path.join(output_dir, "alns_progress_by_time.png"))

    return best_upper, best_lower
