def increase_price(sol: UpperSolution, lower: LowerSolution, data: ProblemData) -> UpperSolution:
    new_sol = sol.copy()
    n, t = data.node_count, data.time_stage_count
    beta2 = 5

    price_changes = []

    operating_links: List[LinkTime] = []
    shadow_prices: List[float] = []
    total_shadow = 0.0

    for i in range(n):
        for j in range(n):
            if not data.uam_link_exists[i, j]:
                continue
            for time in range(t):
                if new_sol.q[i, j, time] > 0:
                    operating_links.append(LinkTime(i, j, time))
                    sp = lower.dual_u2[i, j, time]
                    shadow_prices.append(sp)
                    total_shadow += sp

    if not operating_links:
        return new_sol

    if total_shadow <= 0:
        return new_sol
    probabilities = [sp / total_shadow for sp in shadow_prices]

    od_path_map: Dict[Tuple, List[PathFlow]] = defaultdict(list)
    for p in lower.path_flows:
        od_path_map[(p.origin, p.destination)].append(p)

    path_costs: Dict[int, Dict[int, float]] = {}
    for p in lower.path_flows:
        path_costs[p.path_id] = {}
        for time in range(t):
            path_costs[p.path_id][time] = calculate_path_generalized_cost(p, new_sol, data, time)

    num_ops = min(beta2, len(operating_links))
    for _ in range(num_ops):
        selected_idx = roulette_wheel(probabilities)
        link = operating_links[selected_idx]
        k, m, time = link.i, link.j, link.t

        epsilon = 1
        min_delta = float('inf')

        od_link_usage: Dict[Tuple, PathFlow] = {}
        for p in lower.path_flows:
            if path_contains_uam_link(p, k, m, time):
                od_link_usage[(p.origin, p.destination)] = p

        for r1 in od_link_usage.values():
            od_key = (r1.origin, r1.destination)
            od_paths = od_path_map.get(od_key, [])
            if len(od_paths) < 2:
                continue

            sorted_paths = []
            for p in od_paths:
                cost = path_costs.get(p.path_id, {}).get(time, 0.0)
                sorted_paths.append((p, cost))
            sorted_paths.sort(key=lambda x: x[1])

            r1_idx = -1
            for idx, (p, _) in enumerate(sorted_paths):
                if p.path_id == r1.path_id:
                    r1_idx = idx
                    break

            if r1_idx >= 0 and r1_idx < len(sorted_paths) - 1:
                cost_r1 = sorted_paths[r1_idx][1]
                cost_r2 = sorted_paths[r1_idx + 1][1]
                delta = cost_r2 - cost_r1 - epsilon
                if delta > 0:
                    min_delta = min(min_delta, delta)

        if 5 < min_delta <= 20:
            new_sol.p[k, m, time] += min_delta
        else:
            new_sol.p[k, m, time] *= 1.1

        price_changes.append((k, m, time, sol.p[k, m, time], new_sol.p[k, m, time], min_delta))

    return new_sol

def decrease_price(sol: UpperSolution, lower: LowerSolution, data: ProblemData) -> UpperSolution:
    new_sol = sol.copy()
    n, t = data.node_count, data.time_stage_count
    beta2 = 5

    operating_links: List[LinkTime] = []
    shadow_prices: List[float] = []
    for i in range(n):
        for j in range(n):
            if not data.uam_link_exists[i, j]:
                continue
            for time in range(t):
                if new_sol.q[i, j, time] > 0:
                    operating_links.append(LinkTime(i, j, time))
                    shadow_prices.append(lower.dual_u2[i, j, time])

    if not operating_links:
        return new_sol

    max_shadow = max(shadow_prices)
    weights = [max_shadow - sp for sp in shadow_prices]
    if sum(weights) <= 0:
        weights = [1.0] * len(operating_links)
    num_to_select = min(beta2, len(operating_links))

    od_path_map: Dict[Tuple, List[PathFlow]] = defaultdict(list)
    for p in lower.path_flows:
        od_path_map[(p.origin, p.destination)].append(p)

    path_costs: Dict[int, Dict[int, float]] = {}
    for p in lower.path_flows:
        path_costs[p.path_id] = {}
        for time in range(t):
            path_costs[p.path_id][time] = calculate_path_generalized_cost(p, new_sol, data, time)

    for _ in range(num_to_select):
        selected_idx = roulette_wheel(weights)
        link = operating_links[selected_idx]
        k, m, time = link.i, link.j, link.t

        epsilon = 0.01
        min_delta = float('inf')

        od_link_usage: Dict[Tuple, PathFlow] = {}
        for p in lower.path_flows:
            if path_contains_uam_link(p, k, m, time):
                od_link_usage[(p.origin, p.destination)] = p

        for r1 in od_link_usage.values():
            od_key = (r1.origin, r1.destination)
            od_paths = od_path_map.get(od_key, [])
            if len(od_paths) < 2:
                continue

            sorted_paths = []
            for p in od_paths:
                cost = path_costs.get(p.path_id, {}).get(time, 0.0)
                sorted_paths.append((p, cost))
            sorted_paths.sort(key=lambda x: x[1])

            r1_idx = -1
            for i2, (p, _) in enumerate(sorted_paths):
                if p.path_id == r1.path_id:
                    r1_idx = i2
                    break

            if r1_idx > 0:
                cost_r1 = sorted_paths[r1_idx][1]
                cost_r0 = sorted_paths[r1_idx - 1][1]
                delta = cost_r1 - cost_r0 + epsilon
                if delta > 0:
                    min_delta = min(min_delta, delta)

        if 5 < min_delta <= 20:
            new_sol.p[k, m, time] = max(0, new_sol.p[k, m, time] - min_delta)
        else:
            new_sol.p[k, m, time] *= 0.9

    return new_sol

def reoptimize_flights(sol: UpperSolution, lower: LowerSolution, data: ProblemData,
                       strategy: int = ReallocationStrategy.NONE,
                       affected_nodes: List[int] = None) -> UpperSolution:

    if affected_nodes is None:
        affected_nodes = []

    try:

        current_flow = compute_current_passenger_flow(sol, lower, data)

        updated_flow = reallocate_passenger_flow(
            sol, lower, data, current_flow, strategy, affected_nodes)

        return optimize_flights_and_evtols_with_cplex(sol, data, updated_flow)

    except Exception as e:
        print(f"重新优化UAM航班算子执行错误: {e}")
        return sol

def upgrade_vertiport(sol: UpperSolution, lower: LowerSolution, data: ProblemData) -> Tuple[UpperSolution, List[int]]:
    new_sol = sol.copy()
    n = data.node_count
    h = data.vertiport_level_count
    t = data.time_stage_count
    beta1 = 1

    node_intensity = np.zeros(n)
    for k in range(n):
        s = 0.0
        for m in range(n):
            for time in range(t):
                s += lower.dual_u2[k, m, time] + lower.dual_u2[m, k, time]
        node_intensity[k] = s

    candidate_nodes: List[int] = []
    for k in range(n):
        cur_level = get_vertiport_level(sol, k)
        has_max = (cur_level == h - 1)
        if not has_max:
            candidate_nodes.append(k)

    upgraded_nodes: List[int] = []

    for _ in range(min(beta1, len(candidate_nodes))):

        total_intensity = sum(node_intensity[k] for k in candidate_nodes)
        if total_intensity <= 0:
            probs = [1.0 / len(candidate_nodes)] * len(candidate_nodes)
        else:
            probs = [node_intensity[k] / total_intensity for k in candidate_nodes]

        selected_idx = roulette_wheel(probs)
        node = candidate_nodes[selected_idx]

        cur_level = get_vertiport_level(sol, node)
        if cur_level >= 0:
            new_sol.z[node, cur_level] = 0
            new_level = min(cur_level + 1, h - 1)
            new_sol.z[node, new_level] = 1
        else:
            new_sol.z[node, 0] = 1

        upgraded_nodes.append(node)
        candidate_nodes.pop(selected_idx)

    return new_sol, upgraded_nodes

def downgrade_vertiport(sol: UpperSolution, lower: LowerSolution, data: ProblemData) -> Tuple[UpperSolution, List[int]]:
    new_sol = sol.copy()
    n = data.node_count
    h = data.vertiport_level_count
    t = data.time_stage_count
    beta1 = 1

    node_intensity = np.zeros(n)
    for k in range(n):
        s = 0.0
        for m in range(n):
            for time in range(t):
                s += lower.dual_u2[k, m, time] + lower.dual_u2[m, k, time]
        node_intensity[k] = s

    candidate_nodes: List[int] = []
    for k in range(n):
        if get_vertiport_level(sol, k) >= 0:
            candidate_nodes.append(k)

    downgraded_nodes: List[int] = []

    for _ in range(min(beta1, len(candidate_nodes))):
        max_intensity = max(node_intensity[k] for k in candidate_nodes)
        weights = [max_intensity - node_intensity[k] for k in candidate_nodes]
        total_weight = sum(weights)
        if total_weight <= 0:
            probs = [1.0 / len(candidate_nodes)] * len(candidate_nodes)
        else:
            probs = [w / total_weight for w in weights]

        selected_idx = roulette_wheel(probs)
        node = candidate_nodes[selected_idx]

        cur_level = get_vertiport_level(sol, node)
        if cur_level == 0:

            for level in range(h):
                new_sol.z[node, level] = 0
        else:

            for level in range(h - 1, -1, -1):
                if new_sol.z[node, level] == 1 and level > 0:
                    new_sol.z[node, level] = 0
                    new_sol.z[node, level - 1] = 1
                    break

        downgraded_nodes.append(node)
        candidate_nodes.pop(selected_idx)

    return new_sol, downgraded_nodes

NUM_OPERATORS = 5
OPERATOR_NAMES = [
    "increase_price",
    "decrease_price",
    "reoptimize_flights",
    "upgrade_vertiport",
    "downgrade_vertiport"
]

def apply_operator(op_idx: int, current: UpperSolution, lower: LowerSolution,
                   data: ProblemData) -> Tuple[UpperSolution, LowerSolution]:

    if op_idx == 0:
        new_upper = increase_price(current, lower, data)
    elif op_idx == 1:
        new_upper = decrease_price(current, lower, data)
    elif op_idx == 2:

        new_upper = reoptimize_flights(current, lower, data, ReallocationStrategy.NONE, [])
    elif op_idx == 3:

        new_upper, affected = upgrade_vertiport(current, lower, data)
        new_upper = reoptimize_flights(new_upper, lower, data,
                                       ReallocationStrategy.AFTER_UPGRADE, affected)
    elif op_idx == 4:

        new_upper, affected = downgrade_vertiport(current, lower, data)
        new_upper = reoptimize_flights(new_upper, lower, data,
                                       ReallocationStrategy.AFTER_DOWNGRADE, affected)
    else:
        return current.copy(), lower.copy()
    new_lower = solve_lower_level_parallel(new_upper, data, False)
    return new_upper, new_lower
