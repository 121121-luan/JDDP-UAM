class Builder:

    def __init__(self, name, threads=1, log=None):
        self.m = cplex.Cplex()
        self.m.set_problem_name(name)
        self.m.parameters.threads.set(threads)
        self.m.parameters.simplex.tolerances.feasibility.set(1e-08)
        self.m.parameters.simplex.tolerances.optimality.set(1e-08)
        for method in (self.m.set_log_stream, self.m.set_results_stream, self.m.set_warning_stream, self.m.set_error_stream):
            method(log)

    def var(self, name, lo=0.0, hi=cplex.infinity, kind=None, obj=0.0):
        kw = dict(names=[name], lb=[float(lo)], ub=[float(hi)], obj=[float(obj)])
        if kind:
            kw['types'] = [kind]
        return self.m.variables.add(**kw)[0]

    def row(self, name, pairs, sense, rhs):
        terms = {}
        for (k, v) in pairs:
            terms[k] = terms.get(k, 0.0) + float(v)
        terms = {k: v for (k, v) in terms.items() if abs(v) > 1e-14}
        name = re.sub('[^a-zA-Z0-9_]', '_', name)
        return self.m.linear_constraints.add(names=[name], lin_expr=[cplex.SparsePair(list(terms), list(terms.values()))], senses=[sense], rhs=[float(rhs)])[0]

    def if_zero(self, binary, value, variable, name):
        name = re.sub('[^a-zA-Z0-9_]', '_', name)
        self.m.indicator_constraints.add(indvar=binary, complemented=value == 0, lin_expr=cplex.SparsePair([variable], [1.0]), sense='E', rhs=0.0, name=name)

def specification(data):
    (n, T) = (data.node_count, data.time_stage_count)
    off = ~np.eye(n, dtype=bool)
    if not np.all(np.asarray(data.ground_link_exists)[off]):
        raise ValueError('This implementation requires a complete ground digraph.')
    if n < 2 or data.value_of_time <= 0 or data.passenger_capacity <= 0:
        raise ValueError('Invalid dimensions/VOT/seating capacity.')
    arcs = [(i, j, mode) for i in range(n) for j in range(n) if i != j for (mode, present) in ((0, data.uam_link_exists[i, j]), (1, data.ground_link_exists[i, j])) if present]
    air = [(i, j) for (i, j, mode) in arcs if mode == 0]
    ground = data.ground_travel_fare[:, :, None] + data.value_of_time * data.ground_travel_time
    ca = data.value_of_time * data.uam_travel_time
    if np.any(ground[off] <= 0) or np.any(ca[off] <= 0):
        raise ValueError('Positive base arc costs are required for cycle elimination.')
    demand = np.array(data.od_demand, dtype=float, copy=True)
    for i in range(n):
        demand[i, i, :] = 0
    if np.any(demand < 0):
        raise ValueError('Negative demand.')
    total = demand.sum(axis=1)
    b = -demand.copy()
    for o in range(n):
        b[o, o, :] = total[o, :]
    active = [(o, t) for o in range(n) for t in range(T) if total[o, t] > 1e-10]
    hours = np.asarray(getattr(data, 'period_hours', [4, 6, 4, 10]), dtype=float)
    if hours.shape != (T,):
        raise ValueError('Set data.period_hours for non-four-stage test instances.')
    flying_fraction = float(getattr(data, 'flying_fraction', 0.5))
    pads = data.vertiport_pad_capacity.max(axis=1)
    qmax = {(i, j, t): int(math.floor(data.max_throughput_per_pad[t] * min(pads[i], pads[j]))) for (i, j) in air for t in range(T)}
    mumax = {(i, j, t): max(0.0, ground[i, j, t] - ca[i, j]) for (i, j) in air for t in range(T)}
    price_max = float(ground[off].max())
    return dict(n=n, T=T, arcs=arcs, air=air, ground=ground, ca=ca, demand=demand, total=total, b=b, active=active, hours=hours, flying_fraction=flying_fraction, qmax=qmax, mumax=mumax, price_max=price_max)
