def financials(upper, data, flow):
    construction = float(np.sum(upper.z * data.vertiport_construction_cost))
    flight = float(np.sum(upper.q * data.flight_operation_cost[:, :, None]))
    fleet = float(upper.x[:, 0].sum() * data.evtol_procurement_cost)
    revenue = float(np.sum(upper.p * flow))
    seats = float(data.passenger_capacity * upper.q.sum())
    return dict(profit=revenue - construction - flight - fleet, revenue=revenue, cost=construction + flight + fleet, facility_cost=construction, flight_cost=flight, fleet_cost=fleet, fleet_size=int(upper.x[:, 0].sum()), flights=int(upper.q.sum()), vertiports=int(upper.z.sum()), air_leg_boardings=float(flow.sum()), load_factor=float(flow.sum() / seats) if seats else None, stage_revenue=np.sum(upper.p * flow, axis=(0, 1)).tolist())

def audit_upper(upper, data):
    s = specification(data)
    (incoming, outgoing) = (upper.q.sum(axis=0), upper.q.sum(axis=1))
    parking = (upper.z * data.vertiport_parking_capacity).sum(axis=1)
    pads = (upper.z * data.vertiport_pad_capacity).sum(axis=1)
    available = upper.x.sum(axis=0) * s['hours'] * s['flying_fraction']
    used = (upper.q * data.uam_travel_time[:, :, None]).sum(axis=(0, 1))
    errors = dict(inventory=float(np.max(np.abs(np.roll(upper.x, -1, axis=1) - upper.x - incoming + outgoing))), parking=float(np.max(np.maximum(upper.x - parking[:, None], 0))), throughput=float(np.max(np.maximum(incoming + outgoing - pads[:, None] * data.max_throughput_per_pad, 0))), flight_hours=float(np.max(np.maximum(used - available, 0))), site_levels=float(np.max(np.maximum(upper.z.sum(axis=1) - 1, 0))), integrality=max((float(np.max(np.abs(a - np.rint(a)))) for a in (upper.z, upper.q, upper.x))))
    if any((v > 1e-05 for v in errors.values())) or min(upper.q.min(), upper.x.min(), upper.z.min(), upper.p.min()) < -1e-07:
        raise ValueError(f'Upper feasibility failed: {errors}')
    return errors

def arc_lower(upper, data, optimistic=True, threads=1):
    start = time.perf_counter()
    s = specification(data)
    B = Builder('fixed_upper_arc_LP', threads)
    (f, cost, revenue, balances, capacities) = ({}, {}, {}, {}, {})
    for (o, t) in s['active']:
        for (i, j, mode) in s['arcs']:
            c = s['ca'][i, j] + upper.p[i, j, t] if mode == 0 else s['ground'][i, j, t]
            idx = B.var(f'f_{o}_{i}_{j}_{mode}_{t}', obj=c)
            f[o, i, j, mode, t] = idx
            cost[idx] = c
            revenue[idx] = upper.p[i, j, t] if mode == 0 else 0.0
        for v in range(s['n']):
            terms = [(f[o, i, j, mode, t], 1 if i == v else -1) for (i, j, mode) in s['arcs'] if i == v or j == v]
            balances[o, v, t] = B.row(f'balance_{o}_{v}_{t}', terms, 'E', s['b'][o, v, t])
    for (i, j) in s['air']:
        for t in range(s['T']):
            capacities[i, j, t] = B.row(f'capacity_{i}_{j}_{t}', [(f[o, i, j, 0, t], 1) for (o, tt) in s['active'] if tt == t], 'L', data.passenger_capacity * upper.q[i, j, t])
    B.m.objective.set_sense(B.m.objective.sense.minimize)
    B.m.solve()
    if B.m.solution.get_status() != 1:
        raise RuntimeError(f'Arc lower primary LP: {B.m.solution.get_status_string()}')
    optimum = B.m.solution.get_objective_value()
    pi = {k: B.m.solution.get_dual_values(v) for (k, v) in balances.items()}
    mu = {k: max(0.0, -B.m.solution.get_dual_values(v)) for (k, v) in capacities.items()}
    if optimistic:
        reduced_costs = B.m.solution.get_reduced_costs()
        for (idx, reduced_cost) in enumerate(reduced_costs):
            if reduced_cost > 1e-09:
                B.m.variables.set_upper_bounds(idx, 0.0)
        for (key, row) in capacities.items():
            if mu[key] > 1e-09:
                B.m.linear_constraints.set_senses(row, 'E')
        B.m.objective.set_linear(list(revenue.items()))
        B.m.objective.set_sense(B.m.objective.sense.maximize)
        B.m.solve()
        if B.m.solution.get_status() != 1:
            raise RuntimeError(f'Arc lower tie-break LP: {B.m.solution.get_status_string()}')
    vals = B.m.solution.get_values()
    flows = {k: max(0.0, vals[idx]) for (k, idx) in f.items()}
    air_flow = np.zeros_like(upper.q, dtype=float)
    for ((o, i, j, mode, t), val) in flows.items():
        if mode == 0:
            air_flow[i, j, t] += val
    generalized = sum((cost[idx] * vals[idx] for idx in cost))
    error = max((abs(sum(((1 if i == v else -1) * flows[o, i, j, mode, t] for (i, j, mode) in s['arcs'] if i == v or j == v)) - s['b'][o, v, t]) for (o, v, t) in balances))
    cap_error = float(np.maximum(air_flow - data.passenger_capacity * upper.q, 0).max())
    if error > 1e-05 or cap_error > 1e-05 or abs(generalized - optimum) > 0.0001:
        raise ValueError('Fixed-upper arc validation failed.')
    result = dict(flow=flows, air_flow=air_flow, pi=pi, mu=mu, generalized_cost=generalized, primary_optimum=optimum, balance_error=error, capacity_error=cap_error, seconds=time.perf_counter() - start, optimistic=optimistic, metrics=financials(upper, data, air_flow))
    B.m.end()
    return result

def add_start(B, s, maps, upper, data):
    audit_upper(upper, data)
    u = upper.copy()
    u.p = np.minimum(u.p, s['price_max'])
    ll = arc_lower(u, data, optimistic=True)
    vals = {}
    for name in ('z', 'x', 'q', 'p'):
        for (key, idx) in maps[name].items():
            vals[idx] = float(getattr(u, name)[key])
    potentials = {}
    for (o, t) in s['active']:
        shift = ll['pi'][o, o, t]
        for v in range(s['n']):
            potentials[o, v, t] = ll['pi'][o, v, t] - shift
    mus = {a: min(ll['mu'][a], s['mumax'][a]) for a in maps['mu']}
    for (name, collection) in (('pi', potentials), ('mu', mus)):
        for (key, idx) in maps[name].items():
            vals[idx] = float(collection[key])
    for (key, idx) in maps['f'].items():
        (o, i, j, mode, t) = key
        value = ll['flow'][key]
        reduced = (s['ca'][i, j] + u.p[i, j, t] + mus[i, j, t] if mode == 0 else s['ground'][i, j, t]) - potentials[o, i, t] + potentials[o, j, t]
        vals[idx] = value
        vals[maps['slack'][key]] = max(0.0, reduced)
        vals[maps['used'][key]] = int(value > 1e-08)
    for a in maps['q']:
        cap = data.passenger_capacity * u.q[a] - ll['air_flow'][a]
        vals[maps['capslack'][a]] = max(0.0, cap)
        vals[maps['capbind'][a]] = int(mus[a] > 1e-08)
    for (key, idx) in maps['bits'].items():
        (i, j, t, ell) = key
        bit = int(u.q[i, j, t]) >> ell & 1
        vals[idx] = bit
        vals[maps['product'][key]] = bit * mus[i, j, t]
    B.m.MIP_starts.add(cplex.SparsePair(list(vals), list(vals.values())), B.m.MIP_starts.effort_level.check_feasibility, 'ALNS_arc_verified')
    return ll['metrics']

def certify_incumbent_response(validation, raw_profit, optimistic_profit, profit_upper_bound, tolerance=0.002):
    result = dict(validation)
    result.update(optimistic_profit_residual=abs(raw_profit - optimistic_profit), optimistic_value_overestimate=max(0.0, raw_profit - optimistic_profit), optimistic_profit_above_global_bound=max(0.0, optimistic_profit - profit_upper_bound))
    result['passed'] = all((v <= tolerance for (k, v) in result.items() if k not in ('upper', 'passed', 'optimistic_profit_residual')))
    return result
