def build_exact(data, threads=1, log=None):
    s = specification(data)
    B = Builder('JDDP_origin_arc_exact_MILP', threads, log)
    (n, T, H) = (s['n'], s['T'], data.vertiport_level_count)
    (z, x, q, p, mu, pi, f, slack, used, capslack, capbind, bits, product) = ({} for _ in range(13))
    for i in range(n):
        for h in range(H):
            z[i, h] = B.var(f'z_{i}_{h}', hi=1, kind='B', obj=-data.vertiport_construction_cost[i, h])
        B.row(f'one_level_{i}', [(z[i, h], 1) for h in range(H)], 'L', 1)
        for t in range(T):
            x[i, t] = B.var(f'x_{i}_{t}', hi=data.vertiport_parking_capacity[i].max(), kind='I', obj=-data.evtol_procurement_cost if t == 0 else 0)
            B.row(f'parking_{i}_{t}', [(x[i, t], 1)] + [(z[i, h], -data.vertiport_parking_capacity[i, h]) for h in range(H)], 'L', 0)
    for (i, j) in s['air']:
        for t in range(T):
            a = (i, j, t)
            q[a] = B.var(f'q_{i}_{j}_{t}', hi=s['qmax'][a], kind='I', obj=-data.flight_operation_cost[i, j])
            p[a] = B.var(f'p_{i}_{j}_{t}', hi=s['price_max'])
            mu[a] = B.var(f'mu_{i}_{j}_{t}', hi=s['mumax'][a])
            terms = [(q[a], 1)]
            for ell in range(max(1, s['qmax'][a].bit_length())):
                key = (i, j, t, ell)
                u = bits[key] = B.var(f'bit_{i}_{j}_{t}_{ell}', hi=1, kind='B')
                w = product[key] = B.var(f'w_{i}_{j}_{t}_{ell}', hi=s['mumax'][a], obj=-data.passenger_capacity * 2 ** ell)
                M = s['mumax'][a]
                terms.append((u, -2 ** ell))
                B.row(f'w1_{key}', [(w, 1), (u, -M)], 'L', 0)
                B.row(f'w2_{key}', [(w, 1), (mu[a], -1)], 'L', 0)
                B.row(f'w3_{key}', [(w, 1), (mu[a], -1), (u, -M)], 'G', -M)
            B.row(f'encode_q_{a}', terms, 'E', 0)
    for i in range(n):
        for t in range(T):
            out = [(q[i, j, t], 1) for (ii, j) in s['air'] if ii == i]
            inc = [(q[j, i, t], 1) for (j, jj) in s['air'] if jj == i]
            B.row(f'inventory_{i}_{t}', [(x[i, (t + 1) % T], 1), (x[i, t], -1)] + out + [(idx, -v) for (idx, v) in inc], 'E', 0)
            B.row(f'throughput_{i}_{t}', out + inc + [(z[i, h], -data.max_throughput_per_pad[t] * data.vertiport_pad_capacity[i, h]) for h in range(H)], 'L', 0)
    for t in range(T):
        B.row(f'flying_hours_{t}', [(q[i, j, t], data.uam_travel_time[i, j]) for (i, j) in s['air']] + [(x[i, t], -s['hours'][t] * s['flying_fraction']) for i in range(n)], 'L', 0)
    for (o, t) in s['active']:
        for v in range(n):
            pi[o, v, t] = B.var(f'pi_{o}_{v}_{t}', lo=0 if v == o else -s['ground'][o, v, t], hi=0 if v == o else s['ground'][v, o, t], obj=s['b'][o, v, t])
        for (i, j, mode) in s['arcs']:
            key = (o, i, j, mode, t)
            base = s['ca'][i, j] if mode == 0 else s['ground'][i, j, t]
            f[key] = B.var(f'f_{o}_{i}_{j}_{mode}_{t}', hi=s['total'][o, t], obj=-base)
            slack[key] = B.var(f's_{o}_{i}_{j}_{mode}_{t}')
            used[key] = B.var(f'used_{o}_{i}_{j}_{mode}_{t}', hi=1, kind='B')
            terms = [(slack[key], 1), (pi[o, i, t], 1), (pi[o, j, t], -1)]
            if mode == 0:
                terms += [(p[i, j, t], -1), (mu[i, j, t], -1)]
            B.row(f'dual_slack_{key}', terms, 'E', base)
            B.if_zero(used[key], 0, f[key], f'zero_flow_{key}')
            B.if_zero(used[key], 1, slack[key], f'zero_reduced_cost_{key}')
        for v in range(n):
            B.row(f'flow_balance_{o}_{v}_{t}', [(f[o, i, j, mode, t], 1 if i == v else -1) for (i, j, mode) in s['arcs'] if i == v or j == v], 'E', s['b'][o, v, t])
    for (i, j) in s['air']:
        for t in range(T):
            a = (i, j, t)
            capslack[a] = B.var(f'v_{i}_{j}_{t}', hi=data.passenger_capacity * s['qmax'][a])
            capbind[a] = B.var(f'capbind_{i}_{j}_{t}', hi=1, kind='B')
            B.row(f'capacity_slack_{a}', [(capslack[a], 1), (q[a], -data.passenger_capacity)] + [(f[o, i, j, 0, t], 1) for (o, tt) in s['active'] if tt == t], 'E', 0)
            B.if_zero(capbind[a], 0, mu[a], f'zero_mu_{a}')
            B.if_zero(capbind[a], 1, capslack[a], f'zero_capacity_slack_{a}')
    B.m.objective.set_sense(B.m.objective.sense.maximize)
    maps = dict(z=z, x=x, q=q, p=p, mu=mu, pi=pi, f=f, slack=slack, used=used, capslack=capslack, capbind=capbind, bits=bits, product=product)
    return (B, s, maps)
