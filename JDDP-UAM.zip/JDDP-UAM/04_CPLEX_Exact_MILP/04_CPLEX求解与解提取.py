def solve_exact(data, seconds=1800, gap=1e-06, threads=1, warm_start=None):
    started = time.perf_counter()
    (B, s, maps) = build_exact(data, threads)
    m = B.m
    try:
        m.parameters.timelimit.set(seconds)
        m.parameters.mip.tolerances.mipgap.set(gap)
        m.parameters.mip.tolerances.absmipgap.set(1e-05)
        m.parameters.mip.tolerances.integrality.set(1e-09)
        m.parameters.randomseed.set(42)
        start_metrics = add_start(B, s, maps, warm_start, data) if warm_start is not None else None
        build_seconds = time.perf_counter() - started
        m.parameters.timelimit.set(max(0.001, seconds - build_seconds))
        solving = time.perf_counter()
        m.solve()
        solve_seconds = time.perf_counter() - solving
        status = m.solution.get_status()
        result = dict(status_code=status, status=m.solution.get_status_string(), optimal_within_tolerance=status in (101, 102), requested_gap=gap, time_limit=seconds, build_seconds=build_seconds, solve_seconds=solve_seconds, total_seconds=build_seconds + solve_seconds, threads=threads, variables=m.variables.get_num(), linear_constraints=m.linear_constraints.get_num(), indicators=m.indicator_constraints.get_num(), cplex_version=m.get_version(), warm_start_metrics=start_metrics, profit_upper_bound=float(m.solution.MIP.get_best_objective()), has_incumbent=m.solution.is_primal_feasible())
        upper = None
        if result['has_incumbent']:
            values = np.asarray(m.solution.get_values())
            (n, T, H) = (s['n'], s['T'], data.vertiport_level_count)
            upper = UpperSolution(q=np.zeros((n, n, T), int), p=np.zeros((n, n, T)), z=np.zeros((n, H), int), x=np.zeros((n, T), int))
            for name in ('z', 'x', 'q', 'p'):
                for (key, idx) in maps[name].items():
                    getattr(upper, name)[key] = values[idx] if name == 'p' else int(round(values[idx]))
            air_flow = np.zeros((n, n, T))
            (base_cost, max_complementarity, max_flow_balance) = (0.0, 0.0, 0.0)
            for (key, idx) in maps['f'].items():
                (o, i, j, mode, t) = key
                fval = values[idx]
                base_cost += fval * (s['ca'][i, j] if mode == 0 else s['ground'][i, j, t])
                if mode == 0:
                    air_flow[i, j, t] += fval
                max_complementarity = max(max_complementarity, abs(fval * values[maps['slack'][key]]))
            for (a, idx) in maps['mu'].items():
                max_complementarity = max(max_complementarity, abs(values[idx] * values[maps['capslack'][a]]))
            for (o, t) in s['active']:
                for v in range(n):
                    residual = sum(((1 if i == v else -1) * values[maps['f'][o, i, j, mode, t]] for (i, j, mode) in s['arcs'] if i == v or j == v)) - s['b'][o, v, t]
                    max_flow_balance = max(max_flow_balance, abs(residual))
            dual_value = sum((s['b'][key] * values[idx] for (key, idx) in maps['pi'].items())) - data.passenger_capacity * sum((upper.q[a] * values[idx] for (a, idx) in maps['mu'].items()))
            metrics = financials(upper, data, air_flow)
            reconstructed_gc = base_cost + metrics['revenue']
            ll = arc_lower(upper, data, optimistic=True, threads=threads)
            validation = dict(upper=audit_upper(upper, data), max_flow_balance=max_flow_balance, max_capacity_violation=float(np.maximum(air_flow - data.passenger_capacity * upper.q, 0).max()), max_complementarity=max_complementarity, strong_duality_residual=abs(reconstructed_gc - dual_value), lower_optimal_cost_residual=abs(reconstructed_gc - ll['primary_optimum']), optimistic_profit_residual=abs(metrics['profit'] - ll['metrics']['profit']), objective_profit_residual=abs(metrics['profit'] - m.solution.get_objective_value()))
            validation = certify_incumbent_response(validation, metrics['profit'], ll['metrics']['profit'], result['profit_upper_bound'])
            result.update(profit=float(m.solution.get_objective_value()), optimistic_polished_profit=ll['metrics']['profit'], optimistic_tie_break_loss=ll['metrics']['profit'] - metrics['profit'], relative_mip_gap=float(m.solution.MIP.get_mip_relative_gap()), metrics=metrics, validation=validation, independent_arc_metrics=ll['metrics'])
        if result.get('validation', {}).get('passed') is False:
            raise ValueError('MILP incumbent failed independent verification')
        return (upper, result)
    finally:
        m.end()
